﻿using Microsoft.AspNet.Identity;
using System;
using System.Linq;
using System.Web.UI;
using WebSite4;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Account_Register : Page
{
    SqlConnection con= new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|//Database.mdf;Integrated Security=True")
    protected void CreateUser_Click(object sender, EventArgs e)
    {
        string ins = "Insert Into [StudentRegistration](FirstName, LastName, DOB, Email, UserName, Password) values('" + FirstName.Text + "' , '" + LastName.Text + "', '" + DOB.Text + "', '" + Email.Text + "', '" + UserName.Text + "','" + LastName.Text + "' )";
        var manager = new UserManager();
        var user = new ApplicationUser() { UserName = UserName.Text };
        IdentityResult result = manager.Create(user, Password.Text);
        if (result.Succeeded)
        {
            IdentityHelper.SignIn(manager, user, isPersistent: false);
            IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString);
            con.Open();
        }
        else
        {
            ErrorMessage.Text = result.Errors.FirstOrDefault();
        }
    }
}