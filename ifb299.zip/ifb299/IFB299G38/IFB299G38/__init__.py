"""
Package for IFB299G38.
"""
